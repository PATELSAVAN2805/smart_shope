<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Product ID is missing.");
}

$product_id = intval($_GET['id']);
$query = "SELECT * FROM products WHERE id = $product_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Product not found.");
}

$product = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Buy Product</title>
</head>
<body>
    <h2>Buy Product</h2>
    <form action="buyproductdata.php" method="POST">
        <!-- Hidden Fields -->
        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
        <input type="hidden" name="product_name" value="<?php echo $product['name']; ?>">
        <input type="hidden" name="category" value="<?php echo $product['category']; ?>">
        <input type="hidden" name="price" value="<?php echo $product['price']; ?>">

        <!-- Display Info -->
        <p><strong>Product:</strong> <?php echo $product['name']; ?></p>
        <p><strong>Category:</strong> <?php echo $product['category']; ?></p>
        <p><strong>Price:</strong> ₹<?php echo $product['price']; ?></p>

        <!-- Quantity Input -->
        <label>Quantity:
            <input type="number" name="quantity" value="1" min="1" required>
        </label>
        <br><br>
        <input type="submit" value="Confirm Purchase">
    </form>
</body>
</html>
<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_SESSION['username'];
    $product_id = intval($_POST['p.id']);
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $total = $price * $quantity;

    // Get user ID
    $user_q = "SELECT id FROM users WHERE username='$username'";
    $user_r = mysqli_query($conn, $user_q);
    $user_data = mysqli_fetch_assoc($user_r);
    $user_id = $user_data['id'];

    // Insert into orders table
    $insert = "INSERT INTO orders (user_id, p.id, product_name, category, price, quantity, total_price)
               VALUES ('$user_id', '$product_id', '$product_name', '$category', '$price', '$quantity', '$total')";

    if (mysqli_query($conn, $insert)) {
        echo "✅ Product ordered successfully!";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }
}
?>
