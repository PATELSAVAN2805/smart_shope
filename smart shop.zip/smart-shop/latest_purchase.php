<?php
session_start();
include 'db.php';

// Simulate login if not present
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
}
$user_id = $_SESSION['user_id'];

// Fetch user address
$address_result = mysqli_query($conn, "SELECT address FROM user_addresses WHERE user_id = $user_id");
$user_address = '';
if ($address_result && mysqli_num_rows($address_result) > 0) {
    $user_address = mysqli_fetch_assoc($address_result)['address'];
}

// Get product and quantity from POST
$product_id = (int)($_POST['product_id'] ?? 0);
$quantity = (int)($_POST['qua'] ?? 1);

// Validation
if ($product_id <= 0 || $quantity <= 0) {
    die("❌ Invalid product or quantity.");
}

// Get product
$product_id_safe = mysqli_real_escape_string($conn, $product_id);
$result = mysqli_query($conn, "SELECT * FROM products WHERE id = '$product_id_safe'");
if (!$result || mysqli_num_rows($result) === 0) {
    die("❌ Product not found.");
}
$product = mysqli_fetch_assoc($result);
$stock = (int)$product['quantity'];

// Stock check
if ($quantity > $stock) {
    die("<h3 style='color:red;'>❌ Only $stock item(s) in stock. Cannot purchase $quantity.</h3>");
}

// Calculate total
$unit_price = (float)$product['price'];
$total = $unit_price * $quantity;
$purchase_time = date("Y-m-d H:i:s");

// Insert into purchases
$insert = mysqli_query($conn, "INSERT INTO purchases (user_id, product_id, quantity, total_price, purchase_time)
VALUES ($user_id, $product_id, $quantity, $total, '$purchase_time')");

if (!$insert) {
    die("❌ Failed to save purchase: " . mysqli_error($conn));
}

// Update stock
$new_stock = $stock - $quantity;
$update = mysqli_query($conn, "UPDATE products SET quantity = $new_stock WHERE id = $product_id");

if (!$update) {
    die("❌ Failed to update stock: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Purchase Complete</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f4f8;
        }
        .card {
            background-color: #ffffff;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .back-btn {
            margin-top: 20px;
        }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <div class="alert alert-success">
            ✅ <strong>Purchase Successful!</strong> You bought <strong><?= $quantity ?></strong> × <strong><?= htmlspecialchars($product['name']) ?></strong>.
        </div>

        <ul class="list-group mb-4">
            <li class="list-group-item">Brand: <?= htmlspecialchars($product['brand']) ?></li>
            <li class="list-group-item">Unit Price: ₹<?= number_format($unit_price, 2) ?></li>
            <li class="list-group-item">Total: ₹<?= number_format($total, 2) ?></li>
            <li class="list-group-item">Remaining Stock: <?= $new_stock ?></li>
            <li class="list-group-item">Purchased on: <?= date("d M Y, h:i A", strtotime($purchase_time)) ?></li>

            <?php if ($user_address): ?>
                <li class="list-group-item">
                    <strong>Delivery Address:</strong><br>
                    <?= nl2br(htmlspecialchars($user_address)) ?>
                </li>
            <?php else: ?>
                <li class="list-group-item text-danger">
                    ⚠️ No delivery address found. Please <a href="user_address.php">add one</a>.
                </li>
            <?php endif; ?>
        </ul>

        <a href="user_dashboard.php" class="btn btn-primary back-btn">← Back to Dashboard</a>
    </div>
</body>
</html>
