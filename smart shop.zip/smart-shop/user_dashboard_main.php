<?php
session_start();
include 'db.php';
if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Shop - Category</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f6f9;
      font-family: 'Segoe UI', sans-serif;
    }
    header {
      background: linear-gradient(to right, #343a40, #495057);
      color: white;
    }
    .logout-link {
      color: #ffc107;
      text-decoration: none;
      font-weight: 500;
    }
    .logout-link:hover {
      text-decoration: underline;
      color: #fff;
    }
    .category-btn {
      font-size: 18px;
      font-weight: 600;
      padding: 15px;
      border-radius: 12px;
      transition: all 0.3s ease-in-out;
    }
    .category-btn:hover {
      transform: scale(1.05);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
    }
    footer {
      background-color: #212529;
      color: white;
      text-align: center;
    }
  </style>
</head>
<body>
  <header class="text-center py-4">
    <h2>User Dashboard</h2>
    <p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
    <a href="logout.php" class="logout-link"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </header>

  <main class="container my-5">
    <h3 class="text-center border-bottom pb-3 mb-4">Product Category</h3>
    <div class="row justify-content-center g-4">
      <div class="col-md-3 col-sm-6">
        <a><i class="bi bi-phone"></i> Mobile</a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a><i class="bi bi-laptop"></i> Laptop</a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a><i class="bi bi-tv"></i> TV</a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a><i class="bi bi-tablet"></i> iPad</a> 
        </div>
      </div>
    </div>
    <br>
    <center><a href="user_dashboard.php?category=iPad" class="btn btn-outline-warning w-100 category-btn"><i class="bi bi-tablet"></i> Show All category</a></center>
  </main>

  <footer class="py-3">
    <p class="mb-0">&copy; 2025 Smart Shop. All Rights Reserved.</p>
  </footer>
</body>
</html>
