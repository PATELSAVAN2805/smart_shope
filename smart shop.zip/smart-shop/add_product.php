<?php
include 'db.php';
session_start();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name        = $_POST['name'];
  $brand       = $_POST['brand'];
  $description = $_POST['description'];
  $price       = $_POST['price'];
  $category    = $_POST['category'];
  $quantity    = $_POST['quantity'];

  if ($quantity <= 0) {
    $error = "❌ Quantity must be greater than 0.";
  } else {
    $image      = $_FILES['image']['name'];
    $tmp_name   = $_FILES['image']['tmp_name'];
    $upload_dir = 'uploads/';
    $image_path = $upload_dir . basename($image);

    // Create uploads folder if it doesn't exist
    if (!is_dir($upload_dir)) {
      mkdir($upload_dir, 0755, true);
    }

    // Move uploaded image
    if (move_uploaded_file($tmp_name, $image_path)) {
      $sql = "INSERT INTO products (name, brand, description, price, category, image, quantity)
              VALUES ('$name', '$brand', '$description', '$price', '$category', '$image_path', '$quantity')";

      if (mysqli_query($conn, $sql)) {
        header("Location: view_product.php");
        exit();
      } else {
        $error = "❌ Error inserting product: " . mysqli_error($conn);
      }
    } else {
      $error = "❌ Image upload failed. Ensure 'uploads/' is writable.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Product - Smart Shop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f3f6fa;
    }
    .form-container {
      max-width: 700px;
      margin: auto;
      margin-top: 50px;
      padding: 30px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="container">
  <div class="form-container">
    <h2 class="text-center text-primary mb-4">📦 Add New Product</h2>

    <!-- Error Alert -->
    <?php if (!empty($error)) : ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <!-- Product Form -->
    <form method="POST" enctype="multipart/form-data" onsubmit="return validateQuantity()">
      <div class="mb-3">
        <label class="form-label">📱 Product Name</label>
        <input type="text" name="name" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">🏷️ Brand</label>
        <input type="text" name="brand" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">📝 Description</label>
        <textarea name="description" class="form-control" rows="3" required></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label">💰 Price</label>
        <input type="number" name="price" class="form-control" min="1" required>
      </div>

      <div class="mb-3">
        <label class="form-label">🗂️ Category</label>
        <select name="category" class="form-select" required>
          <option value="">-- Select Category --</option>
          <option value="Mobile">Mobile</option>
          <option value="Laptop">Laptop</option>
          <option value="iPad">iPad</option>
          <option value="TV">TV</option>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">🖼️ Product Image</label>
        <input type="file" name="image" class="form-control" accept="image/*" required>
      </div>

      <div class="mb-3">
        <label class="form-label">📦 Quantity</label>
        <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
      </div>

      <button type="submit" class="btn btn-success w-100">Add Product</button>
    </form>
  </div>
</div>

<!-- JS for Quantity Validation -->
<script>
function validateQuantity() {
  const quantity = document.getElementById("quantity").value;
  if (quantity <= 0 || isNaN(quantity)) {
    alert("❌ Quantity must be greater than 0.");
    return false;
  }
  return true;
}
</script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
