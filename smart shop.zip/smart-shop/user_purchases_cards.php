<?php
session_start();
include 'db.php';

// Simulated login
$user_id = $_SESSION['user_id'] ?? 1;

// Fetch purchases + product + address
$query = "
    SELECT pr.name AS product_name, pr.brand, pr.description, pr.price, 
           p.quantity, p.total_price, p.purchase_time,
           ua.address
    FROM purchases p
    JOIN products pr ON p.product_id = pr.id
    LEFT JOIN user_addresses ua ON p.user_id = ua.user_id
    WHERE p.user_id = $user_id
    ORDER BY p.purchase_time DESC
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Purchased Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link 
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" 
      rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.15);
        }
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-subtitle {
            font-size: 0.95rem;
        }
        .list-group-item {
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="mb-4 text-primary">🛒 Your Purchased Products</h2>

    <div class="row g-4">
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $name = htmlspecialchars($row['product_name']);
                $brand = htmlspecialchars($row['brand']);
                $description = htmlspecialchars($row['description']);
                $unit_price = number_format((float)$row['price'], 2);
                $quantity = (int)$row['quantity'];
                $total = number_format((float)$row['total_price'], 2);
                $time = date("d M Y, h:i A", strtotime($row['purchase_time']));
                $address = !empty($row['address']) ? nl2br(htmlspecialchars($row['address'])) : '<span class="text-danger">No address found</span>';
        ?>
        <div class="col-md-4">
            <div class="card border-primary shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title text-success"><?= $name ?></h5>
                    <h6 class="card-subtitle text-muted mb-2"><?= $brand ?></h6>
                    <p class="card-text small"><?= $description ?></p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Unit Price:</strong> ₹<?= $unit_price ?></li>
                    <li class="list-group-item"><strong>Quantity:</strong> <?= $quantity ?></li>
                    <li class="list-group-item"><strong>Total Price:</strong> ₹<?= $total ?></li>
                    <li class="list-group-item text-muted small"><strong>Purchased On:</strong> <?= $time ?></li>
                    <li class="list-group-item"><strong>Delivery Address:</strong><br><?= $address ?></li>
                </ul>
            </div>
        </div>
        <?php
            }
        } else {
            echo "<div class='col-12'><div class='alert alert-info'>You haven't purchased any products yet.</div></div>";
        }
        ?>
    </div>
</div>

</body>
</html>
