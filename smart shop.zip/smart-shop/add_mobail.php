<?php
include 'db.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Shop - Welcome <?php echo htmlspecialchars($_SESSION['username']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4">Add New Mobile</h2>

  <div class="row justify-content-center">
    <div class="col-md-8">
      <form method="POST" class="p-4 border rounded shadow bg-light" onsubmit="return validateForm()">

        <div class="mb-3">
          <label class="form-label">📱 Mobile Name</label>
          <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">ℹ️ About</label>
          <textarea name="about" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">👍 Advantages</label>
          <textarea name="advantages" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">👎 Disadvantages</label>
          <textarea name="disadvantages" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">💰 Price (₹)</label>
          <input type="number" name="price" class="form-control" id="price" min="1" required placeholder="Enter numeric price">
        </div>

        <div class="mb-3">
          <label class="form-label">🏷️ Brand</label>
          <input type="text" name="brand" class="form-control">
        </div>

        <div class="d-flex justify-content-between">
          <button type="submit" name="save" class="btn btn-primary">Add Mobile</button>
          <a href="viwe_mobile.php" class="btn btn-secondary">View Mobiles</a>
        </div>
      </form>

      <?php
      if (isset($_POST['save'])) {
          $name         = mysqli_real_escape_string($conn, $_POST['name']);
          $about        = mysqli_real_escape_string($conn, $_POST['about']);
          $advantages   = mysqli_real_escape_string($conn, $_POST['advantages']);
          $disadvantages= mysqli_real_escape_string($conn, $_POST['disadvantages']);
          $price        = mysqli_real_escape_string($conn, $_POST['price']);
          $brand        = mysqli_real_escape_string($conn, $_POST['brand']);

          // Optional: Server-side price check
          if (!is_numeric($price) || $price <= 0) {
              echo "<div class='alert alert-danger mt-3'>❌ Invalid price value.</div>";
          } else {
              $sql = "INSERT INTO mobiles (name, about, advantages, disadvantages, price, brand)
                      VALUES ('$name', '$about', '$advantages', '$disadvantages', '$price', '$brand')";
              if (mysqli_query($conn, $sql)) {
                  echo "<div class='alert alert-success mt-3'>✅ Mobile Added Successfully</div>";
              } else {
                  echo "<div class='alert alert-danger mt-3'>❌ Error: " . mysqli_error($conn) . "</div>";
              }
          }
      }
      ?>
    </div>
  </div>
</div>

<!-- JavaScript Alert for Price Validation -->
<script>
function validateForm() {
    const price = document.getElementById("price").value.trim();
    if (price === "" || isNaN(price) || parseFloat(price) <= 0) {
        alert("❌ Please enter a valid numeric price greater than 0.");
        return false;
    }
    return true;
}
</script>

</body>
</html>
