<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Save product ID and quantity to session
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['product_id'])) {
        $_SESSION['selected_product_id'] = (int)$_POST['product_id'];
    }
    if (isset($_POST['qua'])) {
        $_SESSION['quantity'] = (int)$_POST['qua'];
    }
}

$product_id = $_SESSION['selected_product_id'] ?? 0;
if (!$product_id) {
    die("❌ No product selected.");
}

$product_id = mysqli_real_escape_string($conn, $product_id);
$result = mysqli_query($conn, "SELECT * FROM products WHERE id = '$product_id'");
if (!$result || mysqli_num_rows($result) === 0) {
    die("❌ Product not found.");
}
$product = mysqli_fetch_assoc($result);
$stock = (int)$product['quantity'];

// Get logged-in user ID and fetch address
$user_id = $_SESSION['user_id'] ?? 0;
$address_result = mysqli_query($conn, "SELECT address FROM user_addresses WHERE user_id = $user_id");
$user_address = '';
if ($address_result && mysqli_num_rows($address_result) > 0) {
    $user_address = mysqli_fetch_assoc($address_result)['address'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buy Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: rgb(197, 219, 241); }
        .card { background-color: rgb(222, 232, 147); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .input-group button { width: 40px; }
    </style>
</head>
<body class="container mt-5">
    <div class="card p-4">
        <h2><?= htmlspecialchars($product['name']) ?>
            <span class="badge bg-primary">₹<?= htmlspecialchars($product['price']) ?></span>
        </h2>
        <p><strong>Brand:</strong> <?= htmlspecialchars($product['brand']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($product['description']) ?></p>
        <p><strong>Available Stock:</strong> <?= $stock ?></p>

        <!-- Address Block -->
        <?php if ($user_address): ?>
            <div class="alert alert-info">
                <strong>📍 Delivery Address:</strong><br>
                <?= nl2br(htmlspecialchars($user_address)) ?>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                ⚠️ No address saved. <a href="user_address.php" class="btn btn-sm btn-outline-dark">Add Address</a>
            </div>
        <?php endif; ?>

        <!-- Purchase Form -->
        <?php if ($stock <= 0): ?>
            <div class="alert alert-danger mt-3">❌ Out of Stock. Cannot purchase this item.</div>
        <?php else: ?>
            <form method="POST" action="latest_purchase.php">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity (1–<?= $stock ?>)</label>
                    <div class="input-group" style="max-width: 200px;">
                        <button type="button" class="btn btn-outline-secondary" onclick="changeQuantity(-1)">−</button>
                        <input type="number" id="quantity" name="qua" class="form-control text-center" value="1" min="1" max="<?= $stock ?>" required>
                        <button type="button" class="btn btn-outline-secondary" onclick="changeQuantity(1)">+</button>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Confirm Purchase</button>
            </form>
        <?php endif; ?>
    </div>

    <script>
        function changeQuantity(change) {
            const qty = document.getElementById('quantity');
            const min = parseInt(qty.min);
            const max = parseInt(qty.max);
            let value = parseInt(qty.value) || min;
            value += change;
            if (value < min) value = min;
            if (value > max) value = max;
            qty.value = value;
        }
    </script>
</body>
</html>
