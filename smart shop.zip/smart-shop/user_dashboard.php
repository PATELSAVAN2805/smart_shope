<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Shop - Welcome <?php echo htmlspecialchars($_SESSION['username']); ?> <?php echo htmlspecialchars($_SESSION['user_id']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: rgb(150, 185, 237);
            font-family: 'Segoe UI', sans-serif;
        }
        header {
            background: linear-gradient(90deg, #343a40, #495057);
            color: white;
        }
        .logout-link {
            color: #ffc107;
            text-decoration: none;
            font-weight: 500;
        }
        .logout-link:hover {
            color: #fff;
            text-decoration: underline;
        }
        .category-title {
            background-color: #e9ecef;
            padding: 12px;
            font-size: 1.4rem;
            border-radius: 10px;
            margin-top: 40px;
            text-align: center;
            font-weight: 600;
            border-left: 5px solid #0d6efd;
        }
        .card img {
            height: 400px;
            object-fit: cover;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            background-color: rgb(215, 231, 167);
        }
        .card {
            border-radius: 10px;
            transition: transform 0.3s ease;
            background-color: rgb(215, 231, 167);
        }
        .card:hover {
            transform: translateY(-20px);
        }
        footer {
            background-color: #212529;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 60px;
        }
    </style>
</head>
<body>

<header class="text-center py-4">
    <h2>User Dashboard</h2>
    <p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
    <a href="logout.php" class="logout-link">Logout <i class="bi bi-box-arrow-right"></i></a>
    <a href="user_purchases_cards.php" class="btn btn-primary ms-2">Show Purchase Detail</a>
    <a href="user_address.php" class="btn btn-warning ms-2">Manage Address</a>
</header>

<div class="container my-5">
    <?php
    $categories = ['Mobile', 'Laptop', 'TV', 'iPad'];

    foreach ($categories as $category) {
        echo "<div class='category-title'>$category</div>";

        $sql = "SELECT * FROM products WHERE category = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $category);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "<div class='row mt-4'>";
            while ($row = mysqli_fetch_assoc($result)) {
                $image = (!empty($row['image']) && file_exists($row['image'])) ? $row['image'] : 'default.png';

                echo "
                <div class='col-md-4 col-sm-6 mb-4'>
                    <div class='card shadow-sm h-100'>
                        <img src='$image' class='card-img-top' alt='" . htmlspecialchars($row['name']) . "'>
                        <div class='card-body d-flex flex-column'>
                            <h5 class='card-title'>" . htmlspecialchars($row['name']) . "</h5>
                            <p class='card-text'>" . htmlspecialchars($row['description']) . "</p>
                            <p class='text-muted mb-1'>Brand: " . htmlspecialchars($row['brand']) . "</p>
                            <p class='fw-bold text-success'>₹" . htmlspecialchars($row['price']) . "</p>

                            <div class='mt-auto d-flex justify-content-between'>
                                <form method='post' action='product_page.php'>
                                    <input type='hidden' name='product_id' value='" . $row['id'] . "'>
                                    <button type='submit' class='btn btn-outline-primary'>Buy Now</button>
                                </form>
                                <a href='user_address.php' class='btn btn-warning ms-2'>Manage Address</a>
                            </div>
                        </div>
                    </div>
                </div>";
            }
            echo "</div>";
        } else {
            echo "<p class='text-muted text-center mt-3'>No $category products found.</p>";
        }
    }
    ?>
</div>

<footer>
    <p>© 2025 Smart Shop. All rights reserved.</p>
</footer>

</body>
</html>