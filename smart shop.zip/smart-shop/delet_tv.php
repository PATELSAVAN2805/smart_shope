<?php
include 'db.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM tv WHERE id=$id");
header("Location: viwe_tv.php");
?>
