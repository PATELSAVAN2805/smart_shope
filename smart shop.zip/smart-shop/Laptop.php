<?php
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Laptop Cards - Smart Shop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background:rgb(195, 215, 246);
      font-family: 'Segoe UI', sans-serif;
    }
    .card {
      background-color: rgb(215, 231, 167) ;
      border: none;
      border-radius: 15px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
      transition: 0.3s;
    }
    .card:hover {
      transform: translateY(-10px);
    }
    .card-title {
      font-weight: bold;
      font-size: 20px;
    }
    .card-text {
      font-size: 20px;
      color: #555;
      line-height: 1.4;
    }
    h2.title {
      background-color: #fff;
      padding: 15px;
      border-radius: 10px;
      font-weight: bold;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
<header class="text-center bg-dark pb-3">
    <div class="container">
      <h1 class="display-5 fw-bold text-light">SMART SHOP</h1>
      <p class="lead text-light pb-2">Welcome to The Smart Shop, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?>!</p>
      <div>
        <a href="login.php" class="btn btn-outline-light btn-sm me-2">Login</a>
        <a href="signup.php" class="btn btn-outline-warning btn-sm">Signup</a>
      </div>
    </div>
  </header>
<div class="container mt-5">
  <h2 class="text-center mb-4 title border border-3 border-black">Laptop Product List</h2>

  <div class="row g-4">
    <?php
    // FIXED: Removed WHERE clause that was causing error
    $result = mysqli_query($conn, "SELECT * FROM laptop");

    while ($row = mysqli_fetch_assoc($result)) {
    ?>
      <div class="col-md-4">
        <div class="card p-3 h-100">
          <div class="card-body">
            <h5 class="card-title"><i class="bi bi-laptop h1"></i> <?php echo htmlspecialchars($row['name']); ?></h5>
            <p class="card-text mb-1"><strong>Brand:</strong> <?php echo htmlspecialchars($row['brand']); ?></p>
            <p class="card-text mb-1"><strong>Price:</strong> ₹<?php echo htmlspecialchars($row['price']); ?></p>
            <p class="card-text mb-1"><strong>About:</strong> <?php echo htmlspecialchars(substr($row['about'], 0, 80)); ?>...</p>
            <p class="card-text mb-1 text-success"><strong>Advantages:</strong> <?php echo htmlspecialchars($row['advantages']); ?></p>
            <p class="card-text mb-1 text-danger"><strong>Disadvantages:</strong> <?php echo htmlspecialchars($row['disadvantages']); ?></p>
          </div>
        </div>
      </div>
    <?php } ?>
  </div>
</div>

<div class="text-center my-4">
  <h5>Want to buy this product? <a href="signup.php" class="link-primary">Sign Up</a></h5>
</div>

</body>
</html>
