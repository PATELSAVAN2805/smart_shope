<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TV Product List - Smart Shop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
   body {
  background:rgb(195, 215, 246); 
  font-family: 'Segoe UI', sans-serif;
}

.container {
  max-width: 1140px;
}

.title-box {
  background-color: #fff;
  padding: 10px 20px;
  border-radius: 10px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  border-left: 4px solid #0d6efd;
  font-weight: 600;
  font-size: 1.4rem;
}

.card {
  background-color: rgb(215, 231, 167) ;
  border-radius: 14px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
  transition: transform 0.2s;
}

.card:hover {
  transform: translateY(-10px);
}

.card-title {
  font-size: 18px;
  font-weight: 600;
  color: #212529;
}

.card-text {
  font-size: 20px;
  color: #555;
  line-height: 1.4;
}

.card-body {
  padding: 16px;
}

footer {
  background-color: #212529;
  color: white;
  padding: 12px 0;
  font-size: 14px;
  text-align: center;
  margin-top: 40px;
}

  </style>
</head>
<body>
  <header class="text-center bg-dark pb-3">
    <div class="container">
      <h1 class="display-5 fw-bold text-light">SMART SHOP</h1>
      <p class="lead text-light pb-2">Welcome to The Smart Shop, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?>!</p>
      <div>
        <a href="login.php" class="btn btn-outline-light btn-sm me-2">Login</a>
        <a href="signup.php" class="btn btn-outline-warning btn-sm">Signup</a>
      </div>
    </div>
  </header>

  <div class="container my-5">
    <h2 class="text-center mb-4 title-box">📺 TV Product List</h2>

    <div class="row g-4">
      <?php
      $result = mysqli_query($conn, "SELECT * FROM tv");
      if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
      ?>
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title"><i class="bi bi-tv-fill text-primary me-2"></i><?php echo htmlspecialchars($row['name']); ?></h5>
              <p class="card-text"><strong>Brand:</strong> <?php echo htmlspecialchars($row['brand']); ?></p>
              <p class="card-text"><strong>Price:</strong> ₹<?php echo htmlspecialchars($row['price']); ?></p>
              <p class="card-text"><strong>About:</strong> <?php echo htmlspecialchars(substr($row['about'], 0, 90)); ?>...</p>
              <p class="card-text text-success"><strong>Advantages:</strong> <?php echo htmlspecialchars($row['advantages']); ?></p>
              <p class="card-text text-danger"><strong>Disadvantages:</strong> <?php echo htmlspecialchars($row['disadvantages']); ?></p>
            </div>
          </div>
        </div>
      <?php
        }
      } else {
        echo '<p class="text-center text-muted">No TV products available at the moment.</p>';
      }
      ?>
    </div>
  </div>

  <div class="text-center mt-5">
    <p class="fs-5">🛒 Want to buy a product? <a href="signup.php" class="fw-semibold text-decoration-none">Sign up here</a></p>
  </div>

  <footer>
    <p class="mb-0">&copy; <?php echo date('Y'); ?> Smart Shop. All rights reserved.</p>
  </footer>

</body>
</html>
