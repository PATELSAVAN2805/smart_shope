<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username     = $_POST['username'];
    $password     = $_POST['password'];
    $role         = $_POST['role'];
    $email_prefix = $_POST['email_prefix'];
    $mobile_input = $_POST['mobile'];

    $email = $email_prefix . '@gmail.com';
    $mobile = '+91' . $mobile_input;

    // Validate mobile server-side
    if (!preg_match("/^[0-9]{10}$/", $mobile_input)) {
        $error = "❌ Please enter a valid 10-digit mobile number.";
    } else {
        $sql = "INSERT INTO users (username, password, role, email, mobile) 
                VALUES ('$username', '$password', '$role', '$email', '$mobile')";

        if (mysqli_query($conn, $sql)) {
            $success = "✅ Registration successful. <a href='login.php'>Login here</a>";
        } else {
            $error = "❌ Error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sign Up - Smart Shop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #00c6ff, #0072ff);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', sans-serif;
    }
    .signup-box {
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      border-radius: 15px;
      width: 100%;
      max-width: 450px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.2);
    }
    .success { color: green; text-align: center; margin-bottom: 15px; }
    .error { color: red; text-align: center; margin-bottom: 15px; }
  </style>
</head>
<body>

  <div class="signup-box">
    <form method="post" onsubmit="return validateMobile()">
      <h2 class="text-center text-primary">Create Account</h2>

      <?php
        if (!empty($success)) echo "<div class='success'>$success</div>";
        if (!empty($error)) echo "<div class='error'>$error</div>";
      ?>

      <div class="mb-3">
        <input type="text" name="username" class="form-control" placeholder="Username" required>
      </div>

      <div class="mb-3">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
      </div>

      <div class="mb-3">
        <select name="role" class="form-select" required>
          <option value="" disabled selected>Choose Role</option>
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
      </div>

      <!-- Email field with @gmail.com -->
      <div class="mb-3">
        <div class="input-group">
          <input type="text" name="email_prefix" class="form-control" placeholder="Email (without @gmail.com)" required>
          <span class="input-group-text">@gmail.com</span>
        </div>
      </div>

      <!-- Mobile number with +91 prefix and JS validation -->
      <div class="mb-3">
        <div class="input-group">
          <span class="input-group-text">+91</span>
          <input type="text" name="mobile" class="form-control" id="mobile" placeholder="10-digit Mobile Number" required pattern="\d{10}">
        </div>
      </div>

      <button type="submit" class="btn btn-success w-100">Sign Up</button>

      <p class="text-center mt-3">
        Already registered? <a href="login.php">Login here</a>
      </p>
    </form>
  </div>

  <!-- JS Validation for Mobile Number -->
  <script>
    function validateMobile() {
      const mobile = document.getElementById("mobile").value;
      const pattern = /^\d{10}$/;

      if (!pattern.test(mobile)) {
        alert("❌ Please enter a valid 10-digit mobile number.");
        return false;
      }
      return true;
    }
  </script>

</body>
</html>
