<?php
include 'db.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM laptop WHERE id=$id");
header("Location: viwe_laptop.php");
?>
