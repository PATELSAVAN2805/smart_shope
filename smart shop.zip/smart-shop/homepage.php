<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Smart Shop - Welcome <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?></title>

  <!-- Bootstrap CSS & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />

  <style>
    body {
      background-color:rgb(206, 229, 151);
      font-family: 'Segoe UI', sans-serif;
    }
    
    .category-btn {
      font-weight: 600;
      padding: 15px;
      border-radius: 12px;
      transition: 0.3s ease;
      box-shadow: 0 4px 8px rgba(0,0,0,0.08);
    }
    .category-btn:hover {
      transform: translateY(-4px);
      background-color: #0d6efd !important;
      color: #fff !important;
    }
    .section-title {
      font-weight: bold;
      margin-bottom: 30px;
      position: relative;
    }
    .section-title::after {
      content: '';
      display: block;
      width: 60px;
      height: 3px;
      background-color: #0d6efd;
      margin: 10px auto 0;
    }
    .card-header {
      font-weight: 600;
    }
    footer {
      background-color: #212529;
      color: white;
    }
    .why-card i {
      font-size: 3rem;
    }
    .about-section p::before {
      content: "✔ ";
      color: #0d6efd;
    }
    .img-fluid {
      border-radius: 20px;
      max-height: 400px;
      object-fit: cover;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header class="text-center bg-dark ">
    <div class="container bg-dark">
      <h1 class="display-5 text-light fw-bold">SMART SHOP</h1>
      <p class="lead text-light bg-dark">Welcome to The Smart Shop, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?>!</p>
      <div>
        <a href="login.php" class="btn btn-outline-light btn-sm me-2">Login</a>
        <a href="signup.php" class="btn btn-outline-warning btn-sm">Signup</a>
        <br>
        <>br
      </div>
    </div>
  </header>

  <!-- Categories -->
  <section class="container text-center my-5">
    <h4 class="section-title">Explore Our Categories</h4>
    <div class="row g-4 justify-content-center">
      <div class="col-6 col-md-3">
        <a href="mobile.php" class="btn btn-outline-danger w-100 category-btn"><i class="bi bi-phone me-1"></i> Mobile</a>
      </div>
      <div class="col-6 col-md-3">
        <a href="Laptop.php" class="btn btn-outline-dark w-100 category-btn"><i class="bi bi-laptop me-1"></i> Laptop</a>
      </div>
      <div class="col-6 col-md-3">
        <a href="tv.php" class="btn btn-outline-success w-100 category-btn"><i class="bi bi-tv me-1"></i> TV</a>
      </div>
      <div class="col-6 col-md-3">
        <a href="ipad.php" class="btn btn-outline-primary w-100 category-btn"><i class="bi bi-tablet me-1"></i> iPad</a>
      </div>
    </div>
  </section>

  <!-- Why Choose Us -->
  <section class="container my-5">
    <h3 class="text-center section-title">Why Choose Smart Shop?</h3>
    <div class="row text-center g-4">
      <div class="col-md-4 why-card">
        <i class="bi bi-truck text-success"></i>
        <h5 class="mt-3">Fast Delivery</h5>
        <p>Quick nationwide shipping to ensure timely product arrival.</p>
      </div>
      <div class="col-md-4 why-card">
        <i class="bi bi-shield-check text-primary"></i>
        <h5 class="mt-3">Secure Shopping</h5>
        <p>All transactions are encrypted to protect your data.</p>
      </div>
      <div class="col-md-4 why-card">
        <i class="bi bi-award text-warning"></i>
        <h5 class="mt-3">Top Brands</h5>
        <p>We partner only with trusted, quality-certified brands.</p>
      </div>
    </div>
  </section>

  <!-- About Section -->
  <section class="container my-5">
    <h3 class="text-center section-title">About Smart Shop</h3>
    <div class="card p-4 shadow-sm about-section">
      <p class="fs-5">Smart Shop is your one-stop destination for modern electronics, offering:</p>
      <p>Top-brand mobiles, laptops, TVs, and iPads at competitive prices</p>
      <p>A smooth, user-friendly experience for shoppers and admins</p>
      <p>Reliable customer support and efficient delivery services</p>
    </div>
  </section>

  <!-- Footer -->
  <footer class="text-center py-4">
    <p class="mb-0">&copy; 2025 Smart Shop. All Rights Reserved.</p>
  </footer>

</body>
</html>
