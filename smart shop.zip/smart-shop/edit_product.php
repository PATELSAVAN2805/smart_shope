<?php
include 'db.php';

// Get product ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die("Invalid product ID.");
}

// Fetch product data
$result = mysqli_query($conn, "SELECT * FROM products WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("Product not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = intval($_POST['quantity']);

    // Handle image update
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = 'uploads/' . basename($image);
        move_uploaded_file($image_tmp, $image_path);
        $update_image = ", image='$image_path'";
    } else {
        $update_image = "";
    }

    $sql = "UPDATE products SET 
                name='$name', 
                brand='$brand', 
                description='$description', 
                price='$price', 
                quantity=$quantity
                $update_image 
            WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        header("Location: view_product.php");
        exit();
    } else {
        echo "Error updating product: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Product - Smart Shop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6 bg-white p-4 shadow rounded">
      <h2 class="text-center mb-4">Edit Product</h2>
      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($row['name']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Brand</label>
          <input type="text" class="form-control" name="brand" value="<?= htmlspecialchars($row['brand']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Description</label>
          <input type="text" class="form-control" name="description" value="<?= htmlspecialchars($row['description']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Price</label>
          <input type="number" class="form-control" name="price" value="<?= $row['price'] ?>" step="0.01" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Quantity</label>
          <input type="number" class="form-control" name="quantity" value="<?= $row['quantity'] ?>" min="0" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Current Image</label><br>
          <img src="<?= $row['image'] ?>" alt="Product Image" style="max-width: 100px; height: auto;"><br>
        </div>
        <div class="mb-3">
          <label class="form-label">Change Image</label>
          <input type="file" class="form-control" name="image" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary w-100">Update</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
