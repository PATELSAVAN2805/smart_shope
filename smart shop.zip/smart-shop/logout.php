<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Logged Out</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6 text-center p-4 shadow bg-white rounded">
        <h3>You have been logged out.</h3>
        <p>Click below to login again:</p>
        <a href="login.php" class="btn btn-primary">Go to Login</a>
      </div>
    </div>
  </div>
</body>
</html>
