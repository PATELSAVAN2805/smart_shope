<?php include 'db.php'; session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Shop - Welcome <?php echo htmlspecialchars($_SESSION['username']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4">Add New ipad</h2>

  <div class="row justify-content-center">
    <div class="col-md-8">
      <form method="POST" class="p-4 border rounded shadow bg-light">

        <div class="mb-3">
          <label>ipad Name</label>
          <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
          <label>About</label>
          <textarea name="about" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label>Advantages</label>
          <textarea name="advantages" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label>Disadvantages</label>
          <textarea name="disadvantages" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
          <label>Price</label>
          <input type="text" name="price" class="form-control">
        </div>

        <div class="mb-3">
          <label>Brand</label>
          <input type="text" name="brand" class="form-control">
        </div>

        <div class="d-flex justify-content-between">
          <button type="submit" name="save" class="btn btn-primary">Add ipad</button>
          <a href="viwe_ipad.php" class="btn btn-secondary">View ipad</a>
        </div>

      </form>

      <?php
      if (isset($_POST['save'])) {
          $sql = "INSERT INTO ipad (name, about, advantages, disadvantages, price, brand) 
                  VALUES ('{$_POST['name']}', '{$_POST['about']}', '{$_POST['advantages']}', '{$_POST['disadvantages']}', '{$_POST['price']}', 
                          '{$_POST['brand']}')";
          if (mysqli_query($conn, $sql)) {
              echo "<div class='alert alert-success mt-3'>ipad Added Successfully</div>";
          } else {
              echo "<div class='alert alert-danger mt-3'>Error: " . mysqli_error($conn) . "</div>";
          }
      }
      ?>
    </div>
  </div>
</div>

</body>
</html>
