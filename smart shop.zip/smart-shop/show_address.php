<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = ""; // Use your MySQL password if set
$database = "smart-shop"; // Make sure this matches your DB name

$conn = mysqli_connect($servername, $db_username, $db_password, $database);

// Check connection
if (!$conn) {
    die("❌ Connection failed: " . mysqli_connect_error());
}

// Query to fetch usernames and addresses
$sql = "SELECT user_id, address FROM user_addresses";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Addresses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2 class="mb-4">📍 User Addresses</h2>
    
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>User_id</th>
                <th>Address</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="2">No users found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>

<?php
// Close connection
mysqli_close($conn);
?>
