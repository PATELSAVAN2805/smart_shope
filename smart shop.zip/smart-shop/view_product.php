<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Products - Smart Shope</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
<h2 class=" border border-3 border-black text-center pt-3 pb-3">All Products</h2><br>
<center><a href="add_product.php" class="btn btn-primary">+ Add New Product</a></center>
  <?php
  $categories = ['Mobile', 'Laptop', 'iPad', 'TV'];
  foreach ($categories as $cat) {
    echo "<h4 class='mt-4'>$cat</h4>";

    $query = "SELECT * FROM products WHERE category='$cat'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
      echo "<div class='alert alert-danger'>Query Error: " . mysqli_error($conn) . "</div>";
      continue;
    }

    if (mysqli_num_rows($result) > 0) {
      echo "<div class='table-responsive'>
              <table class='table table-bordered table-striped'>
                <thead class='table-dark'>
                  <tr>
                    <th>ID</th>
                    <th>Image</th> 
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Actions</th> 
                  </tr>
                </thead>
                <tbody>";
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td><img src='{$row['image']}' alt='{$row['name']}' style='width: 60px; height: 60px; object-fit: cover;'></td>
                <td>{$row['name']}</td>
                <td>{$row['brand']}</td>
                <td>{$row['description']}</td>
                <td>₹{$row['price']}</td>
                <td>{$row['category']}</td>
                <td>{$row['quantity']}</td>
                <td>
                  <a href='edit_product.php?id={$row['id']}' class='btn btn-sm btn-warning me-2'>Edit</a>
                  <a href='delete_product.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Are you sure you want to delete this product?');\">Delete</a>
                </td>
              </tr>";
      }
      echo "</tbody></table></div>";
    } else {
      echo "<p class='text-muted'>No $cat found.</p>";
    }
  }
  ?>
</div>

</body>
</html>
