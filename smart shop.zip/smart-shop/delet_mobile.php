<?php
include 'db.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM mobiles WHERE id=$id");
header("Location: viwe_mobile.php");
?>
