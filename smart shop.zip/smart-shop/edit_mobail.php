<?php
include 'db.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM mobiles WHERE id=$id"));

$success = '';
if (isset($_POST['update'])) {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $about = mysqli_real_escape_string($conn, $_POST['about']);
  $advantages = mysqli_real_escape_string($conn, $_POST['advantages']);
  $disadvantages = mysqli_real_escape_string($conn, $_POST['disadvantages']);
  $price = mysqli_real_escape_string($conn, $_POST['price']);
  $brand = mysqli_real_escape_string($conn, $_POST['brand']);

  $sql = "UPDATE mobiles SET 
          name='$name', 
          about='$about',
          advantages='$advantages', 
          disadvantages='$disadvantages',
          price='$price', 
          brand='$brand'
          WHERE id=$id";
  if (mysqli_query($conn, $sql)) {
    $success = "✅ Mobile updated successfully!";
    $data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM mobiles WHERE id=$id")); // refresh values
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Mobile - Smart Shop Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-dark text-white">
      <h4>Edit Mobile Product</h4>
    </div>
    <div class="card-body">
      <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
      <?php endif; ?>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($data['name']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">About</label>
          <textarea name="about" class="form-control" rows="2"><?= htmlspecialchars($data['about']) ?></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">Advantages</label>
          <textarea name="advantages" class="form-control" rows="2"><?= htmlspecialchars($data['advantages']) ?></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">Disadvantages</label>
          <textarea name="disadvantages" class="form-control" rows="2"><?= htmlspecialchars($data['disadvantages']) ?></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">Price (₹)</label>
          <input type="number" name="price" class="form-control" value="<?= htmlspecialchars($data['price']) ?>" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Brand</label>
          <input type="text" name="brand" class="form-control" value="<?= htmlspecialchars($data['brand']) ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-primary w-100">Update Mobile</button><br><br>
        <a href="viwe_mobile.php" class="btn btn-secondary w-100">viwe mobile</a>
      </form>
    </div>
  </div>
</div>

</body>
</html>
