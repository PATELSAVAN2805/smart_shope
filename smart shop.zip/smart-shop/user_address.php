<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Access Denied</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container mt-5">
        <div class="alert alert-danger">
            ❌ Please log in to manage your address.
        </div>
        <a href="login.php" class="btn btn-primary">🔐 Go to Login</a>
    </body>
    </html>';
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Handle address form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    $check = mysqli_query($conn, "SELECT * FROM user_addresses WHERE user_id = $user_id");
    if (mysqli_num_rows($check) > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE user_addresses SET address = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $address, $user_id);
        mysqli_stmt_execute($stmt);
        $message = "✅ Address updated successfully!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO user_addresses (user_id, address) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "is", $user_id, $address);
        mysqli_stmt_execute($stmt);
        $message = "✅ Address saved successfully!";
    }
}

// Fetch current address
$stmt = mysqli_prepare($conn, "SELECT address FROM user_addresses WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$current_address = mysqli_fetch_assoc($result)['address'] ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Address</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color:rgb(137, 216, 191);
            font-family: 'Segoe UI', sans-serif;
        }
        .address-box {
            max-width: 600px;
            margin: 60px auto;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }
        .header-line {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-line a {
            font-size: 0.95rem;
        }
    </style>
</head>
<body>

<div class="address-box">
    <div class="header-line mb-4">
        <h3 class="text-primary">🏠 Manage Your Address</h3>
        <span><strong>User:</strong> <?= htmlspecialchars($_SESSION['username']) ?> | <a href="logout.php">Logout</a></span>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="address" class="form-label">📍 Your Address</label>
            <textarea name="address" id="address" class="form-control" rows="5" required><?= htmlspecialchars($current_address) ?></textarea>
        </div>
        <button type="submit" class="btn btn-success w-100">💾 Save Address</button>
    </form>
</div>

</body>
</html>
