<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $product_id = $_POST['product_id'];
  $quantity = $_POST['quantity'];
  $username = $_SESSION['username'];

 $sql = "INSERT INTO orders (username, product_id, quantity, order_date) VALUES (?, ?, ?, NOW())";


  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sii", $username, $product_id, $quantity);
  
  if ($stmt->execute()) {
    header("Location: order_success.php");
    exit();
  } else {
    echo "Error: " . $conn_error;
  }
}
?>
<?php
include 'db.php';
session_start();

$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product List - Smart Shope</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="text-center border-bottom pb-2">Available Products</h2>

  <div class="row">
    <?php while ($row = $result->fetch_assoc()): ?>
    <div class="col-md-4 mb-4">
      <div class="card h-100 shadow">
        <img src="<?php echo $row['image']; ?>" class="card-img-top" style="height: 250px; object-fit: cover;">
        <div class="card-body">
          <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
          <p class="card-text"><strong>Brand:</strong> <?php echo $row['brand']; ?></p>
          <p class="card-text"><?php echo $row['description']; ?></p>
          <p class="card-text"><strong>Price:</strong> ₹<?php echo $row['price']; ?></p>

          <form method="POST" action="buy_product.php">
            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
            <div class="mb-2">
              <label for="quantity_<?php echo $row['id']; ?>" class="form-label">Quantity</label>
              <input type="number" name="quantity" id="quantity_<?php echo $row['id']; ?>" class="form-control" value="1" min="1" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Buy Now</button>
          </form>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>
</body>
</html>

