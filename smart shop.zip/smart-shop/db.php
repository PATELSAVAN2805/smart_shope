<?php
$conn = mysqli_connect("localhost", "root", "", "smart-shop");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
