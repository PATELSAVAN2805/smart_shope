<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "smart-shop";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    die("❌ Database connection failed: " . mysqli_connect_error());
}

// Fetch raw purchases
$sql = "SELECT id, user_id, product_id, quantity, total_price, purchase_time FROM purchases ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
if (!$result) {
    die("❌ Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>📋 Purchase Table</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="text-primary mb-4">🧾 Purchase Records</h2>

    <div class="table-responsive">
        <table class="table table-bordered table-hover text-center align-middle">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Product ID</th>
                    <th>Quantity</th>
                    <th>Total Price (₹)</th>
                    <th>Purchase Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $user_id = $row['user_id'];
                        $product_id = $row['product_id'];
                        $quantity = $row['quantity'] ?? 'NULL';
                        $total_price = $row['total_price'] !== null ? number_format((float)$row['total_price'], 2) : 'NULL';
                        $purchase_time = $row['purchase_time'];

                        echo "<tr>
                                <td>$id</td>
                                <td>$user_id</td>
                                <td>$product_id</td>
                                <td>$quantity</td>
                                <td>$total_price</td>
                                <td>$purchase_time</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-muted'>No purchases found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
