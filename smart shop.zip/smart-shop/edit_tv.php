<?php
include 'db.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tv WHERE id=$id"));
if (isset($_POST['update'])) {
  $sql = "UPDATE laptop SET
          name='{$_POST['name']}', brand='{$_POST['brand']}',
          about='{$_POST['about']}', advantages='{$_POST['advantages']}',
          disadvantages='{$_POST['disadvantages']}', price='{$_POST['price']}'
          WHERE id=$id";
  mysqli_query($conn, $sql);
  header("Location: viwe_tv.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit TV</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <h2>Edit TV</h2>
  <form method="POST" class="border p-4 shadow">
    <input type="text" name="name" class="form-control mb-2" value="<?= $data['name']; ?>">
    <input type="text" name="brand" class="form-control mb-2" value="<?= $data['brand']; ?>">
    <textarea name="about" class="form-control mb-2"><?= $data['about']; ?></textarea>
    <textarea name="advantages" class="form-control mb-2"><?= $data['advantages']; ?></textarea>
    <textarea name="disadvantages" class="form-control mb-2"><?= $data['disadvantages']; ?></textarea>
    <input type="text" name="price" class="form-control mb-2" value="<?= $data['price']; ?>">
    <button name="update" class="btn btn-primary">Update</button>
  </form>
</div>
</body>
</html>
