<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - Smart Shope</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f1f3f6;
      font-family: 'Segoe UI', sans-serif;
    }

    header {
      background-color: #212529;
      color: #fff;
      padding: 40px 20px;
      text-align: center;
    }

    header h1 {
      margin-bottom: 10px;
    }

    .btn-logout {
      color: #ffc107;
      text-decoration: none;
      font-weight: bold;
    }

    .btn-logout:hover {
      text-decoration: underline;
    }

    .category-card {
      transition: 0.3s;
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .category-card:hover {
      transform: scale(1.03);
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
    }

    .category-icon {
      font-size: 40px;
    }

    footer {
      background-color: #212529;
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: 50px;
    }

    .section-title {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 30px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .dashboard-links a {
      text-decoration: none;
    }
  </style>
</head>
<body>

  <header>
    <h1><i class="bi bi-speedometer2"></i> Admin Dashboard</h1>
    <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></p>
    <a href="logout.php" class="btn-logout">Logout</a> |
    <a href="buyproductdata.php" class="btn btn-warning btn-sm">Buy Product Data</a>
    <a href="show_address.php" class="btn btn-warning btn-sm">show address ditail</a>
  </header>

  <main class="container my-5">
    <div class="section-title text-center text-dark">
      Manage Product Categories
    </div>

    <div class="row g-4 dashboard-links">
      <div class="col-md-3 col-sm-6">
        <a href="viwe_mobile.php">
          <div class="card category-card text-center p-4">
            <div class="category-icon text-primary"><i class="bi bi-phone"></i></div>
            <h5 class="mt-3">Mobile</h5>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a href="viwe_laptop.php">
          <div class="card category-card text-center p-4">
            <div class="category-icon text-success"><i class="bi bi-laptop"></i></div>
            <h5 class="mt-3">Laptop</h5>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a href="viwe_tv.php">
          <div class="card category-card text-center p-4">
            <div class="category-icon text-danger"><i class="bi bi-tv"></i></div>
            <h5 class="mt-3">TV</h5>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6">
        <a href="viwe_ipad.php">
          <div class="card category-card text-center p-4">
            <div class="category-icon text-warning"><i class="bi bi-tablet"></i></div>
            <h5 class="mt-3">iPad</h5>
          </div>
        </a>
      </div>
    </div>

    <div class="text-center mt-5">
      <a href="view_product.php" class="btn btn-outline-dark">
        <i class="bi bi-box-seam"></i> View All Product Data
      </a>
    </div>
  </main>

  <footer>
    &copy; 2025 Smart Shope. All rights reserved.
  </footer>

</body>
</html>
