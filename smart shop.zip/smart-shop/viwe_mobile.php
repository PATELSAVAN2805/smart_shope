<?php
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Mobile List - Smart Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="mb-4 text-center border border-3 border-black pb-2 pt-1">Mobile Details</h2>
  <a href="add_mobail.php" class="btn btn-success mb-3">+ Add New Mobile</a>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Brand</th>
        <th>Price</th>
        <th>advantages</th>
        <th>disadvantages</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($conn, "SELECT * FROM mobiles");
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<tr>
              <td>{$row['id']}</td>
              <td>{$row['name']}</td>
              <td>{$row['brand']}</td>
              <td>₹{$row['price']}</td>
              <td>{$row['advantages']}</td>
              <td>{$row['disadvantages']}</td>
              <td>
                <a href='edit_mobail.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                <a href='delet_mobile.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Delete this mobile?\")'>Delete</a>
              </td>
            </tr>";
    }
    ?>
    </tbody>
  </table>
</div>
</body>
</html>
